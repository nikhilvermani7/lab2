import { Injectable } from '@angular/core';
import {Employee} from './employee/Employee';

@Injectable()
export class EmployeeService {

  emp : Employee[]=[];                  //Employee array for service
  constructor() { }
  addemp(e:Employee)               //create refr e to store object from employee array
  {
    this.emp.push(e);         
    console.log(JSON.stringify(e));
  }
  getAllEmp():Employee[]
  {
    return this.emp;
  }
  removeEmp(Id)
  {

    // this.emp.slice(Id);
    this.emp=this.emp.filter(x => x.Id != Id);
    console.log("delete frm service");
  }
  updateEmp(empl:Employee)
  {
    this.removeEmp(empl.Id);
    this.emp.push(empl);
  }
  // updateEmp2(emp2:Employee)
  // {
  //   this.removeEmp(emp2.Id);
  //   this.addemp(emp2);
  // }
}
