import { Component, OnInit } from '@angular/core';
import {Employee} from './Employee';
import {EmployeeService} from '../employee.service';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmployeeService]
})
export class EmployeeComponent implements OnInit {
  emparr:Employee[]=null;                          //to hold data from service in array
  emp : Employee=new Employee();    
  emp2:Employee=new Employee();               //to create json object

  constructor(private employeeservice: EmployeeService) { }
  ngOnInit() {
  }

addEmp(emp:Employee)                               
{
  // if(!this.emp.Id)
  //  {
  // this.employeeservice.addemp(this.emp);               
  // this.emparr=this.employeeservice.getAllEmp();       //to store all data in emparr

  //  }
  // else
  //  {
  // this.employeeservice.updateEmp(this.emp);   
  // this.emparr=this.employeeservice.getAllEmp();  
  //  }


  this.employeeservice.addemp(this.emp);               
  this.emparr=this.employeeservice.getAllEmp();       //to store all data in emparr

   console.log(JSON.stringify(this.emparr));          
   this.emp=new Employee();    
}      

//for new entries
removeEmp(Id)
  {
console.log("deleted");
this.employeeservice.removeEmp(Id);
this.emparr=this.employeeservice.getAllEmp();   //to show remaining data when we delete one id
  }
updateEmp(empl:Employee)
  {
    Object.assign(this.emp2,empl);      //for asigning values to form
  
  }
  updateEmp2(emp2:Employee)
  {
    // this.removeEmp(emp2.Id);
    this.employeeservice.updateEmp(emp2);
    this.emparr=this.employeeservice.getAllEmp();
    // this.addemp(emp2);
    this.emp2=new Employee();   
  }
}

