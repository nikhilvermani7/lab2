export class Employee
{

  Id:number;
  Name:string;
  Salary:string;
  Dept:string;
}